#!/bin/bash

ORIG_PREFIX="/opt/local/lib"
NEW_PREFIX="@loader_path"

# now update all references to .dylib files to use @loader_path
for lib in *.dylib; do
    lib=`echo $lib | sed -e 's/2.3.1/2.3/'`
    for target in *.dylib; do
        echo Change "$ORIG_PREFIX/$lib" to "$NEW_PREFIX/$lib" in $target
        install_name_tool -change "$ORIG_PREFIX/$lib" "$NEW_PREFIX/$lib" $target
    done
done

# handle zlib
for target in *.dylib; do
    echo Change "$ORIG_PREFIX/libz.1.dylib" to "/usr/lib/libz.1.dylib" in $target
    install_name_tool -change "$ORIG_PREFIX/libz.1.dylib" "/usr/lib/libz.1.dylib" $target
done
